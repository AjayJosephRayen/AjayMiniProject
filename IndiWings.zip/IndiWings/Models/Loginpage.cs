﻿using System;
using System.Collections.Generic;

namespace IndiWings.Models
{
    public partial class Loginpage
    {
        public int Sno { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
