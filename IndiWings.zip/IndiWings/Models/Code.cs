﻿using System;
using System.Collections.Generic;

namespace IndiWings.Models
{
    public partial class Code
    {
        public string? City { get; set; }
        public string Citycode { get; set; } = null!;
    }
}
